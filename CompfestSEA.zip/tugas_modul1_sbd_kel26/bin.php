<?php
// Create database connection using config file
include_once("config.php");
// Fetch data
$mahasiswa = mysqli_query($mysqli, "SELECT * FROM mahasiswa WHERE is_delete=1 ORDER BY id_mahasiswa DESC");
$buku = mysqli_query($mysqli, "SELECT * FROM buku WHERE is_delete=1 ORDER BY kode_buku DESC");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initialscale=1.0">
        <title>Homepage</title>
    </head>
    <body>
        <h1>Catatan Malaikat</h1>
        <h3>Tabel Data Barang</h3>
        <table width='80%' border=1>
            
            <tr>
            <th>Kode Barang</th> <th>Nama Barang</th> <th>Jenis</th> <th>Merk</th> <th>Aksi</th>
            </tr>
            <?php
            while($item = mysqli_fetch_array($mahasiswa)) {
                echo "<tr>";
                echo "<td>".$item['id_mahasiswa']."</td>";
                echo "<td>".$item['nama_mahasiswa']."</td>";
                echo "<td>".$item['jurusan']."</td>";
                echo "<td>".$item['semester']."</td>";
                echo "<td><a href='restoreMahasiswa.php?id=$item[id_mahasiswa]'>Restore</a> | <a href='deletePMahasiswa.php?id=$item[id_mahasiswa]'>Delete</a></td></tr>";
            }
            ?>
        </table>
        <h3>Tabel Data Saldo</h3>
        <table width='80%' border=1>
            <tr>
                <th>Kode Transaksi</th> <th>Jumlah Bayar</th> <th>Mata Uang</th> <th>Barang Dibeli</th> <th>Metode Bayar</th> <th>Aksi</th>
            </tr>
            <?php
            while($item = mysqli_fetch_array($buku)) {
                echo "<tr>";
                echo "<td>".$item['kode_buku']."</td>";
                echo "<td>".$item['judul_buku']."</td>";
                echo "<td>".$item['pengarang']."</td>";
                echo "<td>".$item['jenis_buku']."</td>";
                echo "<td>".$item['penerbit']."</td>";
                echo "<td><a href='restoreBuku.php?id=$item[kode_buku]'>Restore</a> | <a href='deletePBuku.php?id=$item[kode_buku]'>Delete</a></td></tr>";
            }
            ?>
        </table>
        <p>
        </p>
        <a href='index.php'>dashboard</a>
    </body>
</html>
<?php
// include database connection file
include_once("config.php");
// Check if form is submitted for data update, then redirect to homepage after update
if(isset($_POST['update']))
{
    $kode = $_POST['kode'];
    $judul=$_POST['judul'];
    $pengarang=$_POST['pengarang'];
    $jenis=$_POST['jenis'];
    $penerbit=$_POST['penerbit'];
    // update data
    $result = mysqli_query($mysqli, "UPDATE buku SET judul_buku='$judul',pengarang='$pengarang',jenis_buku='$jenis',penerbit='$penerbit' WHERE kode_buku=$kode");
    // Redirect to homepage to display updated data in list
    header("Location: index.php");
}
?>
<?php
// Display selected makanan based on id
// Getting id from url
$id = $_GET['id'];
// Fetch data based on id
$result = mysqli_query($mysqli, "SELECT * FROM buku WHERE kode_buku=$id");
while($buku = mysqli_fetch_array($result))
{
    $judul = $buku['judul_buku'];
    $pengarang = $buku['pengarang'];
    $jenis = $buku['jenis_buku'];
    $penerbit = $buku['penerbit'];
}
?>
<html>
    <head>
        <title>Edit Data Buku</title>
    </head>
    <body>
        <a href="index.php">Home</a>
        <br/><br/>
        <h2>Edit Data Buku</h2>
        <form name="update_buku" method="post" action="editBuku.php">
            <table border="0">
                <tr>
                    <td>Kode Buku</td>
                    <td><input type="text" name="id" value=<?php echo $id;?>></td>
                </tr>
                <tr>
                    <td>Judul Buku</td>
                    <td><input type="text" name="judul" value=<?php echo $judul;?>></td>
                </tr>
                <tr>
                <tr>
                    <td>Pengarang</td>
                    <td><input type="text" name="pengarang" value=<?php echo $pengarang;?>></td>
                </tr>
                <tr>
                    <td>Jenis Buku</td>
                    <td><input type="text" name="jenis" value=<?php echo $jenis;?>></td>
                </tr>
                <tr>
                    <td>Penerbit</td>
                    <td><input type="text" name="penerbit" value=<?php echo $penerbit;?>></td>
                </tr>
                <tr>
                <td><input type="hidden" name="id" value=<?php echo

$_GET['id'];?>></td>
                    <td><input type="submit" name="update" value="Update"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
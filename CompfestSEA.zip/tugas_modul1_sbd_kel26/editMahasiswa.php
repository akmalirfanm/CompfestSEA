<?php
// include database connection file
include_once("config.php");
// Check if form is submitted for data update, then redirect to homepage after update
if(isset($_POST['update']))
{
    $nim = $_POST['nim'];
    $nama=$_POST['nama'];
    $jurusan=$_POST['jurusan'];
    $semester=$_POST['semester'];
    // update data
    $result = mysqli_query($mysqli, "UPDATE mahasiswa SET nama_mahasiswa='$nama',jurusan='$jurusan',semester='$semester' WHERE id_mahasiswa=$nim");
    // Redirect to homepage to display updated data in list
    header("Location: index.php");
}
?>
<?php
// Display selected makanan based on id
// Getting id from url
$id = $_GET['id'];
// Fetch data based on id
$result = mysqli_query($mysqli, "SELECT * FROM mahasiswa WHERE id_mahasiswa=$id");
while($mahasiswa = mysqli_fetch_array($result))
{
    $nama = $mahasiswa['nama_mahasiswa'];
    $jurusan = $mahasiswa['jurusan'];
    $semester = $mahasiswa['semester'];
}
?>
<html>
    <head>
        <title>Edit Data Mahasiswa</title>
    </head>
    <body>
        <a href="index.php">Home</a>
        <br/><br/>
        <h2>Edit Data Mahasiswa</h2>
        <form name="update_mahasiswa" method="post" action="editMahasiswa.php">
            <table border="0">
                <tr>
                    <td>NIM</td>
                    <td><input type="text" name="nim" value=<?php echo $id;?>></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td><input type="text" name="nama" value=<?php echo $nama;?>></td>
                </tr>
                <tr>
                <tr>
                    <td>Jurusan</td>
                    <td><input type="text" name="jurusan" value=<?php echo $jurusan;?>></td>
                </tr>
                <tr>
                    <td>Semester</td>
                    <td><input type="text" name="semester" value=<?php echo $semester;?>></td>
                </tr>              
                <tr>
                    <td><input type="submit" name="update" value="Update"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
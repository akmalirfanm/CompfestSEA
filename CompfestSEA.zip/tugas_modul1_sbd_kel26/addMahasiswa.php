<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initialscale=1.0">
        <title>Tambahkan Barang</title>
    </head>
    <body>
        <a href="index.php">Go to Home</a>
        <br/><br/>
        <h2>Data Barang</h2>

        <form action="addMahasiswa.php" method="post" name="form1">
            <table width="25%" border="0">
                <tr>
                    <td>Kode Barang</td>
                    <td><input type="text" name="nim"></td>
                </tr>
                <tr>
                    <td>Nama Barang</td>
                    <td><input type="text" name="nama"></td>
                </tr>
                <tr>
                    <td>Jenis</td>
                    <td><input type="text" name="jurusan"></td>
                </tr>
                <tr>
                    <td>Merk</td>
                    <td><input type="text" name="semester"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="Submit" value="Tambahkan"></td>
                </tr>
            </table>
        </form>
        <?php
        // Check If form submitted, insert form data into users table.
        if(isset($_POST['Submit'])) {
            $nim = $_POST['nim'];
            $nama = $_POST['nama'];
            $jurusan = $_POST['jurusan'];
            $semester = $_POST['semester'];
            // include database connection file
            include_once("config.php");
            // Insert user data into table
            $result = mysqli_query($mysqli, "INSERT INTO mahasiswa(id_mahasiswa, nama_mahasiswa, jurusan, semester) VALUES('$nim','$nama','$jurusan','$semester')");
            // Show message when user added\
            echo "Berhasil menambahkan data Mahasiswa <a href='index.php'>dashboard</a>";
        }
        ?>
    </body>
</html>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initialscale=1.0">
        <title>Tambahkan Saldo</title>
    </head>
    <body>
        <a href="index.php">Go to Home</a>
        <br/><br/>
        <h2>Data Saldo</h2>

        <form action="addBuku.php" method="post" name="form1">
            <table width="25%" border="0">
                <tr>
                    <td>Kode Transaksi</td>
                    <td><input type="text" name="kode"></td>
                </tr>
                <tr>
                    <td>Jumlah Bayar</td>
                    <td><input type="text" name="judul"></td>
                </tr>
                <tr>
                    <td>Mata Uang</td>
                    <td><input type="text" name="pengarang"></td>
                </tr>
                <tr>
                    <td>Barang Dibeli</td>
                    <td><input type="text" name="jenis"></td>
                </tr>
                <tr>
                    <td>Metode Bayar</td>
                    <td><input type="text" name="penerbit"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="Submit" value="Tambahkan"></td>
                </tr>
            </table>
        </form>
        <?php
        // Check If form submitted, insert form data into users table.
        if(isset($_POST['Submit'])) {
            $kode = $_POST['kode'];
            $judul = $_POST['judul'];
            $pengarang = $_POST['pengarang'];
            $jenis = $_POST['jenis'];
            $penerbit = $_POST['penerbit'];
            // include database connection file
            include_once("config.php");
            // Insert user data into table
            $result = mysqli_query($mysqli, "INSERT INTO buku(kode_buku, judul_buku, pengarang, jenis_buku, penerbit) VALUES('$kode','$judul','$pengarang','$jenis','$penerbit')");
            // Show message when user added\
            echo "Berhasil menambahkan data Buku <a href='index.php'>dashboard</a>";
        }
        ?>
    </body>
</html>
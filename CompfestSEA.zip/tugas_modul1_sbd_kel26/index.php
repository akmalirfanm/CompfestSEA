<?php
// Create database connection using config file
include_once("config.php");
// Fetch data
$mahasiswa = mysqli_query($mysqli, "SELECT * FROM mahasiswa WHERE
is_delete=0 ORDER BY id_mahasiswa ASC");
$buku = mysqli_query($mysqli, "SELECT * FROM buku WHERE
is_delete=0 ORDER BY kode_buku ASC");
$pinjam = mysqli_query($mysqli, "SELECT pinjam.id_pinjam,
pinjam.tgl_pinjam,
mahasiswa.id_mahasiswa,
mahasiswa.nama_mahasiswa,
buku.kode_buku,
buku.judul_buku
FROM pinjam
INNER JOIN mahasiswa ON pinjam.id_mahasiswa = mahasiswa.id_mahasiswa
INNER JOIN buku ON pinjam.kode_buku = buku.kode_buku ORDER BY tgl_pinjam ASC");
?>

<?php
// Check If form submitted, insert form data into users table.
if(isset($_POST['Submit'])) {
    $tanggal = $_POST['tanggal'];
    $nim = $_POST['nim'];
    $kode = $_POST['kode'];
    // include database connection file
    include_once("config.php");
    $result = mysqli_query($mysqli, "INSERT INTO pinjam(tgl_pinjam, id_mahasiswa, kode_buku) VALUES('$tanggal','$nim','$kode')");
    header("Location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-
        scale=1.0">
        <title>Homepage</title>
    </head>
    <body>
        <h1>SELAMAT DATANG</h1>
        <h1>Kantin Kejujuran SEA</h1>
        <h3>Tabel Data Barang</h3>
        <table width='80%' border=1>
            <a href="addMahasiswa.php">Tambah Data Barang</a>
            <tr>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Jenis</th>
                <th>Merk</th>
                <th>Aksi</th>
            </tr>
            <?php
            while($item = mysqli_fetch_array($mahasiswa)) {
                echo "<tr>";
                echo "<td>".$item['id_mahasiswa']."</td>";
                echo "<td>".$item['nama_mahasiswa']."</td>";
                echo "<td>".$item['jurusan']."</td>";
                echo "<td>".$item['semester']."</td>";
                echo "<td><a href='editMahasiswa.php?id=$item[id_mahasiswa]'>Edit</a>
                | <a href='deleteMahasiswa.php?id=$item[id_mahasiswa]'>Beli</a></td></tr>";
            }
            ?>
        </table>
        <br/>
        <h3>Tabel Data Saldo</h3>
        <table width='80%' border=1>
            <a href="addBuku.php">Tambah Data Saldo</a>
            <tr>
                <th>Kode Transaksi</th>
                <th>Jumlah Bayar</th>
                <th>Mata Uang</th>
                <th>Barang Dibeli</th>
                <th>Metode Bayar</th>
                <th>Aksi</th>
            </tr>
            <?php
            while($item = mysqli_fetch_array($buku)) {
                echo "<tr>";
                echo "<td>".$item['kode_buku']."</td>";
                echo "<td>".$item['judul_buku']."</td>";
                echo "<td>".$item['pengarang']."</td>";
                echo "<td>".$item['jenis_buku']."</td>";
                echo "<td>".$item['penerbit']."</td>";
                echo "<td><a href='editBuku.php?id=$item[kode_buku]'>Edit</a>
                | <a href='deleteBuku.php?id=$item[kode_buku]'>Ambil Uang</a></td></tr>";
            }
            ?>
        </table>
        <br/>
        <h3>Tabel Data Log Kantin</h3>
        <form action="index.php" method="post" name="form1">
            <table width="25%" border="0">
                <tr>
                    <td>Kode Barang</td>
                    <td><input type="text" name="nim"></td>
                </tr>
                <tr>
                    <td>Kode Transaksi</td>
                    <td><input type="text" name="kode"></td>
                </tr>
                <tr>
                    <td>Tanggal Beli</td>
                    <td><input type="date" name="tanggal"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="Submit" value="Tambahkan"></td>
                </tr>
            </table>
        </form>
        <br/>
        <table width='80%' border=1>
            <tr>
                <th>Tanggal Pinjam</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Kode Transaksi</th>
                <th>Jumlah Bayar</th>
                <th>Aksi</th>
            </tr>
            <?php
            while($item = mysqli_fetch_array($pinjam)) {
                echo "<tr>";
                echo "<td>".$item['tgl_pinjam']."</td>";
                echo "<td>".$item['id_mahasiswa']."</td>";
                echo "<td>".$item['nama_mahasiswa']."</td>";
                echo "<td>".$item['kode_buku']."</td>";
                echo "<td>".$item['judul_buku']."</td>";
                echo "<td><a href='deletePinjam.php?id=$item[id_pinjam]'>Delete</a></td></tr>";            
            }
            ?>
        </table>
        <a href="bin.php"><br><br>Catatan Malaikat</a>
    </body>
</html>
<?php
$databaseHost = 'localhost';
$databaseName = 'tugas_modul1_kel26';
$databaseUsername = 'root';
$databasePassword = '';
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
?>